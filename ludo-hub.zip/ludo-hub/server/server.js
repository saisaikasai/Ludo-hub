'use strict';
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const express = require('express');
const { Server } = require('socket.io');
const G = require('../public/js/logic.js');

const PORT = process.env.PORT || 3000;
const ORIGIN = process.env.ALLOWED_ORIGIN || '*';
const MAX_ROOM = 8;
const EMOJIS = ['😂','😮','👏','🔥','😭','😈','😍','🤯','🎉','👍','😡','🥳','😎','🙈','💀','❤️'];
const GRACE_MS = 10 * 60 * 1000;

const app = express();
app.disable('x-powered-by');
app.use(express.static(path.join(__dirname, '..', 'public')));
app.get('/health', (_req, res) => res.json({ ok: true, rooms: rooms.size }));

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: ORIGIN === '*' ? true : ORIGIN.split(','), methods: ['GET', 'POST'] } });

/** @type {Map<string, any>} */
const rooms = new Map();

const rid = (n) => crypto.randomBytes(n).toString('hex');
const clean = (s, max) => String(s == null ? '' : s).replace(/[\u0000-\u001f\u007f<>]/g, '').trim().slice(0, max);
function makeCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  for (;;) {
    let c = ''; for (let i = 0; i < 5; i++) c += A[crypto.randomInt(A.length)];
    if (!rooms.has(c)) return c;
  }
}
function iceServers() {
  const list = [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }];
  if (process.env.TURN_URL) list.push({ urls: process.env.TURN_URL.split(','), username: process.env.TURN_USER, credential: process.env.TURN_PASS });
  return list;
}

/* simple per-socket rate limiter */
function allow(socket, key, max, perMs) {
  const now = Date.now();
  const b = (socket.data.rl = socket.data.rl || {});
  const e = (b[key] = b[key] || { t: now, n: 0 });
  if (now - e.t > perMs) { e.t = now; e.n = 0; }
  return ++e.n <= max;
}

function publicRoom(r) {
  return {
    code: r.code, game: r.game, started: r.started, host: r.hostPid,
    players: r.players.map((p, seat) => ({ pid: p.pid, seat, name: p.name, connected: p.connected, voice: p.voice, muted: p.muted }))
  };
}
const emitRoom = (r) => io.to(r.code).emit('room:update', publicRoom(r));
function sys(r, text) { io.to(r.code).emit('chat:msg', { system: true, text, ts: Date.now() }); }
const seatOf = (r, pid) => r.players.findIndex(p => p.pid === pid);

function sendState(r, events, only) {
  if (!r.state) return;
  r.players.forEach((p, seat) => {
    if (!p.connected || !p.sid || (only && only !== p.sid)) return;
    io.to(p.sid).emit('game:state', { state: G.view(r.state, seat), events: events || [], seat });
  });
}

function pickHost(r) {
  if (r.players.some(p => p.pid === r.hostPid && p.connected)) return;
  const n = r.players.find(p => p.connected);
  if (n) { r.hostPid = n.pid; sys(r, n.name + ' is now the host.'); }
}

/* Auto-play for disconnected players so the game never gets stuck. */
function scheduleAuto(r) {
  if (!r.state || r.autoTimer) return;
  const absent = G.actors(r.state).filter(seat => r.players[seat] && !r.players[seat].connected);
  if (!absent.length) return;
  r.autoTimer = setTimeout(() => {
    r.autoTimer = null;
    if (!r.state) return;
    const seat = G.actors(r.state).find(s => r.players[s] && !r.players[s].connected);
    if (seat === undefined) return;
    const a = G.auto(r.state, seat);
    if (a) {
      const res = G.apply(r.state, a, seat);
      if (!res.error) sendState(r, res.events);
    }
    scheduleAuto(r);
  }, 1800);
}

function leaveVoice(r, p) {
  if (!p.voice) return;
  p.voice = false; p.muted = false;
  io.to(r.code).emit('voice:left', p.pid);
}

function removePlayer(r, p) {
  leaveVoice(r, p);
  const i = r.players.indexOf(p);
  if (i !== -1) r.players.splice(i, 1);
  if (p.sid) { const s = io.sockets.sockets.get(p.sid); if (s) { s.leave(r.code); s.data.room = null; s.data.pid = null; } }
  pickHost(r);
  if (!r.players.length) { clearTimeout(r.autoTimer); rooms.delete(r.code); return; }
  emitRoom(r);
}

io.on('connection', (socket) => {
  const ctx = () => {
    const r = rooms.get(socket.data.room);
    if (!r) return {};
    const p = r.players.find(x => x.pid === socket.data.pid);
    return p ? { r, p } : {};
  };

  function attach(r, p, ack, joined) {
    p.sid = socket.id; p.connected = true; p.lastSeen = Date.now();
    socket.data.room = r.code; socket.data.pid = p.pid;
    socket.join(r.code);
    pickHost(r);
    ack({ ok: true, code: r.code, pid: p.pid, key: p.key, ice: iceServers(), room: publicRoom(r) });
    if (joined) sys(r, p.name + ' joined the room.'); else sys(r, p.name + ' reconnected.');
    emitRoom(r);
    if (r.state) sendState(r, [], socket.id);
  }

  socket.on('room:create', (d, ack) => {
    if (typeof ack !== 'function') return;
    if (!allow(socket, 'create', 5, 60000)) return ack({ ok: false, error: 'Slow down a little.' });
    const name = clean(d && d.name, 16) || 'Player';
    const game = G.META[d && d.game] ? d.game : 'ludo';
    const code = makeCode();
    const r = { code, game, started: false, state: null, hostPid: null, players: [], autoTimer: null, created: Date.now(), party: true };
    const p = { pid: rid(4), key: rid(12), name, sid: null, connected: true, voice: false, muted: false };
    r.players.push(p); r.hostPid = p.pid;
    rooms.set(code, r);
    attach(r, p, ack, true);
  });

  socket.on('room:join', (d, ack) => {
    if (typeof ack !== 'function') return;
    if (!allow(socket, 'join', 10, 60000)) return ack({ ok: false, error: 'Too many attempts. Wait a moment.' });
    const code = clean(d && d.code, 8).toUpperCase();
    const r = rooms.get(code);
    if (!r) return ack({ ok: false, error: 'Room not found. Check the code.' });
    // rejoin with key
    if (d.key) {
      const p = r.players.find(x => x.key === d.key);
      if (p) {
        if (p.sid && p.sid !== socket.id) { const old = io.sockets.sockets.get(p.sid); if (old) { old.data.room = null; old.leave(r.code); } }
        return attach(r, p, ack, false);
      }
    }
    if (r.started) return ack({ ok: false, error: 'That game has already started.' });
    if (r.players.length >= MAX_ROOM) return ack({ ok: false, error: 'Room is full.' });
    const name = clean(d.name, 16) || 'Player';
    const p = { pid: rid(4), key: rid(12), name, sid: null, connected: true, voice: false, muted: false };
    r.players.push(p);
    attach(r, p, ack, true);
  });

  socket.on('room:set-game', (d) => {
    const { r, p } = ctx(); if (!r || r.hostPid !== p.pid || r.started) return;
    if (!G.META[d && d.game]) return;
    r.game = d.game; emitRoom(r);
  });

  socket.on('room:start', (_d, ack) => {
    ack = typeof ack === 'function' ? ack : () => {};
    const { r, p } = ctx(); if (!r) return ack({ ok: false, error: 'Not in a room.' });
    if (r.hostPid !== p.pid) return ack({ ok: false, error: 'Only the host can start.' });
    const meta = G.META[r.game];
    const n = r.players.length;
    if (n < meta.min || n > meta.max) {
      return ack({ ok: false, error: meta.min === meta.max ? meta.name + ' needs exactly ' + meta.min + ' players.' : meta.name + ' needs ' + meta.min + '-' + meta.max + ' players.' });
    }
    r.state = G.create(r.game, n, { party: true });
    r.started = true;
    ack({ ok: true });
    sys(r, meta.name + ' started!');
    emitRoom(r); sendState(r, [{ type: 'start' }]);
    scheduleAuto(r);
  });

  socket.on('room:lobby', () => {
    const { r, p } = ctx(); if (!r || r.hostPid !== p.pid) return;
    r.started = false; r.state = null; clearTimeout(r.autoTimer); r.autoTimer = null;
    r.players = r.players.filter(x => x.connected);
    io.to(r.code).emit('game:end');
    emitRoom(r);
  });

  socket.on('game:action', (d) => {
    if (!allow(socket, 'act', 20, 5000)) return;
    const { r, p } = ctx(); if (!r || !r.state || !d) return;
    const seat = seatOf(r, p.pid);
    const res = G.apply(r.state, d.action, seat);
    if (res.error) return socket.emit('game:error', res.error);
    sendState(r, res.events);
    scheduleAuto(r);
  });

  socket.on('chat:send', (d) => {
    if (!allow(socket, 'chat', 8, 5000)) return;
    const { r, p } = ctx(); if (!r) return;
    const text = clean(d && d.text, 300); if (!text) return;
    io.to(r.code).emit('chat:msg', { pid: p.pid, seat: seatOf(r, p.pid), name: p.name, text, ts: Date.now() });
  });

  socket.on('emoji:send', (d) => {
    if (!allow(socket, 'emoji', 8, 3000)) return;
    const { r, p } = ctx(); if (!r || !d || !EMOJIS.includes(d.emoji)) return;
    io.to(r.code).emit('emoji:show', { pid: p.pid, seat: seatOf(r, p.pid), name: p.name, emoji: d.emoji });
  });

  /* ---------------- voice chat signaling (WebRTC mesh) ---------------- */
  socket.on('voice:join', () => {
    const { r, p } = ctx(); if (!r) return;
    const peers = r.players.filter(x => x.voice && x.pid !== p.pid).map(x => x.pid);
    p.voice = true; p.muted = false;
    socket.emit('voice:peers', peers);
    emitRoom(r);
  });
  socket.on('voice:leave', () => { const { r, p } = ctx(); if (!r) return; leaveVoice(r, p); emitRoom(r); });
  socket.on('voice:mute', (d) => { const { r, p } = ctx(); if (!r) return; p.muted = !!(d && d.muted); emitRoom(r); });
  socket.on('voice:signal', (d) => {
    if (!allow(socket, 'sig', 120, 5000)) return;
    const { r, p } = ctx(); if (!r || !d) return;
    const to = r.players.find(x => x.pid === d.to && x.connected && x.sid);
    if (to) io.to(to.sid).emit('voice:signal', { from: p.pid, data: d.data });
  });

  socket.on('room:leave', () => { const { r, p } = ctx(); if (!r) return; sys(r, p.name + ' left.'); removePlayer(r, p); });

  socket.on('disconnect', () => {
    const { r, p } = ctx(); if (!r) return;
    if (p.sid !== socket.id) return;           // already re-attached from a new socket
    p.connected = false; p.sid = null; p.lastSeen = Date.now();
    leaveVoice(r, p);
    if (!r.started) { removePlayer(r, p); sys(r, p.name + ' left.'); return; }
    sys(r, p.name + ' disconnected – a bot will play for them until they return.');
    pickHost(r); emitRoom(r); scheduleAuto(r);
  });
});

/* Remove abandoned rooms */
setInterval(() => {
  const now = Date.now();
  for (const [code, r] of rooms) {
    if (r.players.every(p => !p.connected) && now - Math.max(...r.players.map(p => p.lastSeen || r.created)) > GRACE_MS) {
      clearTimeout(r.autoTimer); rooms.delete(code);
    }
  }
}, 60000).unref();

server.listen(PORT, () => console.log('Game Hub running on http://localhost:' + PORT));
